运行：
pip install -r requirements.txt
python app.py

打开： http://127.0.0.1:5000

